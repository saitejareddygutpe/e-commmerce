<?php

include('Con.php');


check();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="First.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="full">
    <div class="first">
    <div class="title" >
        <a href="Web1.php">
            <div class="logo">
            <img src="Logo.png" widht="1%" height="1%" alt="HTML tutorial" />
            
        </a>
        <div class="hline">
        <hr >
        </div>
        <div class="nav-bar">
        <nav class="navbar navbar-dark bg-dark">
            <div class="container-fluid">
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item" style="padding-right: 20px;">
                    <a class="nav-link active" aria-current="page" href="#">Home</a>
                  </li>
                  <li class="nav-item dropdown" style="padding-right: 20px;">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Products
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <li><a class="dropdown-item" href="Products1.php">LED'S</a></li>
                      <!li><hr class="dropdown-divider"></li>
                      <li><a class="dropdown-item" href="Products2.php">Decorative Lights</a></li>
                      <!li><hr class="dropdown-divider"></li>
                      <li><a class="dropdown-item" href="Products3.php">Interior Lighting</a></li>
                      <li><hr class="dropdown-divider"></li>
                      <li><a class="dropdown-item" href="Products4.php">New Products</a></li>
                    </ul>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">About Us</a>
                  </li>
                  <li>
                    <div class="tp" style="display: flex; flex-direction: row;">
                    <div class="login" style="margin-top: -3.5cm ;">
                      <a style="margin-left:3cm;text-decoration:None; color: aliceblue;"  href="MyAcc.php">MyAccount</a>
                    </div>
                    <div class="login1" style="margin-top:-3.5cm ;">
                      <a style="margin-left: 1cm; font-size: 24px;text-decoration:None; color: aliceblue;"  href="Login.php">Logout</a>
                    </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
    </div>
</div>
</div>
    <!!111!!>
    <div class="bg-beside-text" >
        <h1> ILLuminating lives </h1>
        <h4> Joy and Happiness</h4>
    </div>
    <div class="bgimage">
    </div>
    <!!! TOP PART OF BODY>
    <div class="desc" style="margin-top: 3cm;">
        <div class="desc1" style="margin-top: 1cm;">
        <p>
            Service 
        </p>
        </div>
        <div class="desc2" style="margin-top: 1cm;">
        <p> 
            Excellence
        </p>
        </div>
        <div class="desc3" style="margin-top: 1cm;">
        <p>
            Customer-Satisfaction
        </p>  
    </div>
    </div>
    <div class="para">
        <p>
            Welcome!! the hub of bulbs by LITETECH .
             we cover LED, Tubelights, Profile lights and interior lights  for your home, office, car and more. 
             They come in an impressive variety of shapes, styles and fittings. 
             Whether you want to create the perfect atmosphere for your living space, 
             energise your work area, explore how colour adds ambiance, 
             complement your decor or simply save energy and reduce household bills, 
             there's something for you. And it doesn’t have to be a challenge to find what’s best for you,
              because we’ve launched the Bulb Advisor. It's fun and easy to use, 
              and ensures you always choose the right bulb for your needs.
        </p>
    </div>
    <div class="finishes">
        <h1> These are some of our finest works</h1>
    </div>
    <div class="projects">
        <img src="PRojects 5.jpeg" width="500" height="500">
        <img src="Projects1.jpeg" width="500" height="500">
        <img src="Projects2.jpeg" width="500" height="500">
        <img src="Projects3.jpeg" width="500" height="500">
        <img src="Projects4.jpeg" width="500" height="500">
        <img src="Project 5.jpeg" width="500" height="500">
    </div>
    <div class="hline" style="margin-top:2cm;">
    </div>





    <! BBBBOOOTTTOOOM>




    <div class="bottom">

        <div class="bottom1">

          <div class="bottom11">

            <a href="#"  class="fa fa-facebook"></a>  
            <a href="#" class="fa fa-twitter"></a>  
            <a href="#" class="fa fa-linkedin"></a>  
            <a href="#" class="fa fa-instagram"></a>   
        <br>

          </div>

          <div class="bottom12">

            <div class="ICON" >
            <i  style="margin-top: 14px;" class="fa fa-phone" style="font-size:44px"></i>
            <a style="margin-top: 0.7cm;" href="+917989696141">+917989696141</a>
            </div>

            <div class="ICON" >
              <i  style="margin-top: 3px;" class="fa fa-phone" style="font-size:44px"></i>
              <a style="margin-top: 0.4cm;" href="+919871298873">+919871298873</a>
              </div>

              <div class="ICON" >
                <i style="margin-top: 0px;" class="fa fa-envelope"></i>
                <a style="margin-top: 0.4cm;"  href="contact@LITETECH.in">contact@LITETECH.in</a>
              </div>
              
            <div class="ICON2">
            <img src="Maps.jpeg" style=" margin-left: 10px; border-radius:10px; display: flex; flex-direction: row;"  width="50" height="50">
            
            <p>   
            LiteTech,2nd floor Above Reliance Fresh,
            Opposite to galleria, somajigua, Hyderabad.
            Telangana - 500023
            </p>
            </div>

          </div>

        </div>
        

        <div class="border1">

            

        </div>

        <div class="bottom2">
          <h6>Disclaimer</h6>
        The product colours and shades displayed on 
        this website are only indicative and cannot 
        be considered to be precise representation 
        of the actual colors.

        </div>

        <div class="border1">



        </div>

        <div class="bottom3">

          <h6 style="margin-top:1.5cm;">
            Customer Care
        </h6>
        <p style="width:10cm">
            If you have any complaints/issues with our products please reach us through the following ways
        </p>
        <a href="+91-7899870123"><i class="fa fa-phone" ></i> +91-7899870123</a>  
        <br><br>
        <a href="+91-8978799878"><i class="fa fa-phone" ></i> +91-8978799878</a>
        <br><br>
        <a href="contact@LITETECH.in"><i class="fa fa-envelope"></i>  contact@LITETECH.in</a>
        <br>

        </div>


    </div>





  </div>

  <script src="Js.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>