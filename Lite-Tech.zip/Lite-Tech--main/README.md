# Lite-Tech-

                            # CONTACT_BOOK  -- WebApplication(Project) By Aditya Mogili,Rajesh Pathi and Sai Teja gutpe
                            
             The Above Projet is a E-Commerce Webapplication(Store) where one can order things(items), this web application is built as 
            
                                  a part an Mini Project also it is intended for Pursonal Use.
                                  
                                  
                    The Above applicationis inteded  for selling of Tube Lights,Interior Lights in online mode
                    
                    *) User Functionality
                    -> User Needs to create an account
                    -> After logging in User can navigatr through differnt Items we sell
                    -> User can also navigate to Home Page Where We descibe About Our Store
                    -> User can navigate to his Transaction History where he find his all past orders
                    -> User is also able to buy things(items) 
                    
                    *) Admin Functionality 
                    -> Admin has the privilege to add new items
                    -> After adding new items user's can also see updated items
                    -> Admin can see through all the users transaction history
                    
             
             Technoligies Used:
             
             *) Front-End Technoligies:
             -> HTML,CSS
             
             *) Front-End Frame Work:
             -> Bootstrap
             
             *) Server side scripting Languages
             -> PHP
             
             *) Data Base
             -> MySQL
             
             *) Other Languages/Technoligies:
             -> Java Script
             
             
         
             
             
             
                    
                    
                    
                    
             
             
